/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infs2605.assignment;

/**
 *
 * @author paulstrasser
 */
public class Student {
    
    public String zID;
    public String firstname;
    public String lastname;
    public double wam;
    
}
