/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package infs2605.assignment;

import java.util.ArrayList;

public class UserDB {
    protected ArrayList<Integer> IDs = new ArrayList<Integer>();
    protected ArrayList<String> FNames = new ArrayList<String>();
    protected ArrayList<String> LNames = new ArrayList<String>();
    protected ArrayList<Integer> userType = new ArrayList<Integer>();
    protected ArrayList<String> Gender = new ArrayList<String>();
    protected ArrayList<Integer> Age = new ArrayList<Integer>();
    protected ArrayList<String> homeNum = new ArrayList<String>();
    protected ArrayList<String> email = new ArrayList<String>();
    protected ArrayList<Integer> hNum = new ArrayList<Integer>();
    protected ArrayList<String> hStreet = new ArrayList<String>();
    protected ArrayList<String> hSuburb = new ArrayList<String>();
    protected ArrayList<String> hCity = new ArrayList<String>();
    protected ArrayList<String> hPostCode = new ArrayList<String>();
}
